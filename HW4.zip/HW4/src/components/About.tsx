import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about">
      <h2>About Me</h2>
      <p>
        Hello! I'm Kalmykov Inal, 1st year student of Innopolis University. I have experience in HTML, CSS, C, C++ and JS. I enjoy learning new technologies and constantly improving my skills.
      </p>
    </section>
  );
};

export default About;
